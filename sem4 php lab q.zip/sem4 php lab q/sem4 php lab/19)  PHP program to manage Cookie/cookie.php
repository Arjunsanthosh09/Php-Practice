<?php

setcookie("Arjun","100",  time() + (86400 * 30),'/');

print_r($_COOKIE);
?>